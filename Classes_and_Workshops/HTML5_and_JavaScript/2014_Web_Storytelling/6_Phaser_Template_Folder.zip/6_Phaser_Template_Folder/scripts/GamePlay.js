myGame.GamePlay.prototype = {
  preload: function() {
    // Preload images for this state
  },

  create: function() {
    // Create objects
    console.log("GamePlay");
  },

  update: function() {
    // Update objects & variables
  }
}
