
var randomNumber;

function setup() {
 createCanvas(400, 400);
 frameRate(1);
}

function draw() {
  clear();

  // Let's put a random number into the variable
  randomNumber = random();


// when the randomNumber is smaller the 1/2 (0.5) we show a ellipse
  if (randomNumber < (1/2)) {
      noStroke();
      fill(250,0,200);
      ellipse(width/2,(height/2)-100,50)
  }

  // we will have a look at this one later
  // randomNumber = round(random(1,10));

  fill(0);
  textSize(15);
  text("Random Number " + randomNumber, 100,height/2);

}
