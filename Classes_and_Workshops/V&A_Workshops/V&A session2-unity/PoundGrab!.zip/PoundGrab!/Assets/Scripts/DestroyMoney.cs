﻿using UnityEngine;
using System.Collections;

public class DestroyMoney : MonoBehaviour {

	//
    void OnTriggerEnter2D(Collider2D other)
    {
        //Destroys the GameObject that belongs to other
        Destroy(other.gameObject, 1.0f);
    }
}
