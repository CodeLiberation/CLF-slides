﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {
    //variables
    public Camera myCam;
    private float maxWidth;
    public GameObject money;

    //Variables to store time details
    private float timeLeft;
    public Text timerText;



    // Use this for initialization
    void Start () {
        timeLeft = 20;
        if (myCam == null)
        {
            myCam = Camera.main;
        }

        Vector2 uppercorner = new Vector2(Screen.width, Screen.height);
        Vector2 targetwidth = myCam.ScreenToWorldPoint(uppercorner);
        //instead of using renderer I used a small figure as its not likely to leave the screen.
        maxWidth = targetwidth.x - 5;

        StartCoroutine(Spawn());

    }

    IEnumerator Spawn()
    {
        //yield/wait causes a delay before completing the function
        yield return new WaitForSeconds(1.0f);

        while (timeLeft > 0)
        {


            //This randomly picks a position on the x-axis between the edges of the screen and stores it in a variable
            Vector2 spawnPosition = new Vector2(
                        Random.Range(-maxWidth, maxWidth), transform.position.y);
            //Quaternion is what unity uses to represent rotations. Quaternion.identity suggests no rotation
            Quaternion spawnRotation = Quaternion.identity;

            //Instantiate creates prefab in position set with no difference in rotation
            Instantiate(money, spawnPosition, spawnRotation);
            yield return new WaitForSeconds(Random.Range(1.0f, 2.0f));
        }

    }

    void FixedUpdate()
    {
        //Creates count down
        timeLeft -= Time.deltaTime;
        //when timer hits 0 stop countdown.
        if (timeLeft < 0)
        {
            timeLeft = 0;
            SceneManager.LoadScene("GameOver", LoadSceneMode.Single);
        }
        //This replace the text in the textbox in the inspectors
        timerText.text = "TimeLeft: " + Mathf.RoundToInt(timeLeft);
    }
     
}
