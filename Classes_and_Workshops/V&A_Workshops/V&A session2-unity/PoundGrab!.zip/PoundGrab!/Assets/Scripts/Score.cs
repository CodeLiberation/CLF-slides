﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Score : MonoBehaviour {
    //Create variables to hold Text component and score
    public Text counter;
    private int score;
    // Use this for initialization
    void Start () {

        score = 0;
        UpdateScore();
	  
}

    //When money hits the bag, score increases by 5
    void OnTriggerEnter2D(Collider2D other)
    {
        score += 5;
        //call this function to update score 
        UpdateScore();
    }
    //this function overwrites the text of score
    void UpdateScore()
    {
        counter.text = "Money: £" + score;
    }
}

