﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

    //Our variables
    public Camera myCam;
    public Rigidbody2D rbBag;
    public Renderer rend;
    private float maxWidth;

    // Use this for initialization
    void Start () {
        //put main camera in myCam variable

        if (myCam == null)
        {
            myCam = Camera.main;
        }

        //Grab RigidBody2D component from inspector 
        rbBag = GetComponent<Rigidbody2D>();
        //Store the size of the screen
        Vector2 uppercorner = new Vector2(Screen.width, Screen.height);
        //transform local space to world space
        Vector2 targetwidth = myCam.ScreenToWorldPoint(uppercorner);

        //Grab Renderer component from inspector
        rend = GetComponent<Renderer>();
        //The renderer knowd the size of the Graphic, ask for the size and store it
        //bounds gets bounding volume of renderer
        //extents is half of the size
        float bagWidth = rend.bounds.extents.x;
        //max width of the screen we can move in
        maxWidth = targetwidth.x - bagWidth;
        

    }

    // Update is called evry constant amount of time
    //handles phsycis as it needs to be determinstic
    void FixedUpdate () {
        //We need the mouse position
        //Input is the interface to the input system
        //mouse position is the current mouse position in pixels (readonly)
        Vector2 rawMousePosition = myCam.ScreenToWorldPoint(Input.mousePosition);
        //Set the playercontroller position to the mouse positon on the x axis
        Vector2 targetPosition = new Vector2(rawMousePosition.x, 0.0f);


        //Clamp player movement to the width of the screen on the left(-) and right(+)
        //Mathf.Clamp clamps a value between min and max
        float targetWidth = Mathf.Clamp(targetPosition.x, -maxWidth, maxWidth);
        //update target position, tell it the new set limiations
        targetPosition = new Vector2(targetWidth, targetPosition.y);

        //move the playerController
        rbBag.MovePosition(targetPosition);

	}
}
