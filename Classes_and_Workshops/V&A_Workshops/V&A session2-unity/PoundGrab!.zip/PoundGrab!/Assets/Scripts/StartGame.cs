﻿using UnityEngine;
using UnityEngine.SceneManagement;

using System.Collections;

public class StartGame : MonoBehaviour
{

    // Update is called once per frame
    void Update()
    {
        //Getkeydown(keyCode.Return) acknowledges when Enter is pressed
        if (Input.GetKeyDown(KeyCode.Return))
        {
            Debug.Log("pressed");
            SceneManager.LoadScene("MainGame", LoadSceneMode.Single);
        }


    }
}
    
