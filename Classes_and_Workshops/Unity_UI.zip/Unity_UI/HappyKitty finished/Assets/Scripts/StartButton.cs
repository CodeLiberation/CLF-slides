﻿using UnityEngine;

public class StartButton : MonoBehaviour {

	public void OnClickBtnPlay() {
		Application.LoadLevel ("Game"); 
	}
}
