﻿using UnityEngine;
using System.Collections;

public class Variables : MonoBehaviour {

    //this is our first variable 
    int x = 10; 

	// Use this for initialization
	void Start () {
        //this line of code let's us print out to the console in unity. 
        Debug.Log(x + " is the value of x");  

	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
